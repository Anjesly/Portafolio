<!-- Barra de control -->
<div class="control-bar">
    <button class="theme-switcher" id="mobileThemeSwitcher">
        <i class="fas fa-desktop"></i>
        <span>Windows Mode</span>
    </button>
    <a href="#" class="action-button" data-action="coffee">
        <i class="fas fa-coffee"></i>
        <span>Buy Me Coffee</span>
    </a>
</div>