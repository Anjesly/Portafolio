<!-- Estadísticas -->
<div class="stats-container">
    <div class="stat-card">
        <span class="stat-value">8+</span>
        <span class="stat-label">Apps</span>
    </div>
    <div class="stat-card">
        <span class="stat-value">3</span>
        <span class="stat-label">Projects</span>
    </div>
    <div class="stat-card">
        <span class="stat-value">4K+</span>
        <span class="stat-label">Lines</span>
    </div>
    <div class="stat-card">
        <span class="stat-value">5</span>
        <span class="stat-label">Years</span>
    </div>
</div>