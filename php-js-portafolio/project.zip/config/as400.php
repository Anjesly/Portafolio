<?php

global $dbconect;

//	CONEXION AS400
function CONECTARAS400() {

	//error_reporting(0);

    global $dbconect;
	
	$user = 'USERGRAL';
	$pass = 'USERGRAL';
	$ip   = '192.1.1.2';
	
	//	Driver de Conexion
	$dsn="Driver={Client Access ODBC Driver (32-bit)};
		  System=$ip;
		  Uid=$user;
		  Pwd=$pass;";
	
	//	Conexion
    $dbconect = odbc_connect($dsn,$user,$pass); 
	
    if ($dbconect == 0) { 

		header("Location: errorAS400.php");
		
		exit();
    }else{
		//echo ("Conexión Exitosa al AS400");
	}
}

function DESCONECTARAS400() {
	
	global $dbconect;
	
    odbc_close($dbconect);
	
}

?>