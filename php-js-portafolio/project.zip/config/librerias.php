<?php

$archivos=[];
$ruta = "../config/libreriasDevs.txt"; // Reemplaza con el nombre del archivo deseado
if (filesize($ruta) > 0 && is_readable($ruta)) {
    $contenido = file($ruta);
    foreach ($contenido as $linea) {
        // Muestra cada línea del archivo
        $partesLinea = explode(';', $linea);
        $alias = $partesLinea[0];
        $archivo = $partesLinea[1];
        $archivos[$alias] = $archivo;
    }
} else {
    echo "El archivo no existe o es inaccesible.";
}

?>