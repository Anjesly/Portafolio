<?php
if (!defined('DB_HOST')) {
    die("Error: Constantes de base de datos no definidas.");
}

?>